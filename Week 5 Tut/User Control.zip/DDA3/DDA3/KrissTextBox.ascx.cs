﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DDA3
{
    public partial class KrissTextBox : System.Web.UI.UserControl
    {
        public String TextValue
        {
            get { return TextBox1.Text; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text.ToUpper();
        }
    }
}
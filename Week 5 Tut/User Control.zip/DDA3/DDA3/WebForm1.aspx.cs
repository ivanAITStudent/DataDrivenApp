﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DDA3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Control oControl1 = this.LoadControl("~/KrissTextBox.ascx");
            Control oControl2 = this.LoadControl("~/KrissTextBox.ascx");
            Control oMyNewLine;

            oMyNewLine = this.ParseControl(@"<br />");

            oControl1.ID = "myControl1";
            oControl2.ID = "myControl2";

            this.PlaceHolder1.Controls.Add(oControl1);
            this.PlaceHolder1.Controls.Add(oMyNewLine);
            this.PlaceHolder1.Controls.Add(oControl2);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Label2.Text = textBox1.TextValue;

            KrissTextBox oTmp = (KrissTextBox)this.FindControl("myControl1");

            Label3.Text = oTmp.TextValue;

            oTmp = (KrissTextBox)this.FindControl("myControl2");

            Label4.Text = oTmp.TextValue;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DDA2
{
    public partial class TestCostomControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Label mylabel1 = new Label();


                //mylabel1.Text = "Hello world";
                //placeholder1.Controls.Add(mylabel1);

                //MyControl MyControl1 = new MyControl();

                //placeholder1.Controls.Add(MyControl1);

                //1. check the current question?

                //2. check the answer type, checkbox, listbox, radio button etc....

                //3. Add the control to page dynamicly. Depend on step 2

                //4. Populate value from the sources, session, DB, etc....

                //5. Get answer from respondant and then save it some where...

                //6. If not end, redirect to myself.
            }
        }
    }
}
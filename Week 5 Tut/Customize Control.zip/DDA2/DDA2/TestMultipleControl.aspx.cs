﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DDA2
{
    public partial class TestMultipleControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                for (int i = 1; i <= 15; i++)
                {
                    ListBox1.Items.Add("Option " + i.ToString());
                    DropDownList1.Items.Add("Option " + i.ToString());
                    CheckBoxList1.Items.Add("Option " + i.ToString());
                    RadioButtonList1.Items.Add("Option " + i.ToString());
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("<b>Select items for ListBox1:</b><br/>");
            foreach (ListItem myList in ListBox1.Items)
            {
                if (myList.Selected)
                {
                    Response.Write("- " + myList.Text + "<br/>");
                }
            }

            Response.Write("<b>Select items for DropDownList1:</b><br/>");
            Response.Write("- " + DropDownList1.SelectedItem.Text + "<br/>");

            Response.Write("<b>Select items for CheckBoxList1:</b><br/>");
            foreach (ListItem myList in CheckBoxList1.Items)
            {
                if (myList.Selected)
                {
                    Response.Write("- " + myList.Text + "<br/>");
                }
            }

            Response.Write("<b>Select items for RadioButtonList1:</b><br/>");
            Response.Write("- " + RadioButtonList1.SelectedItem.Text + "<br/>");
        }
    }
}
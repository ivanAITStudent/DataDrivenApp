﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Custom_User_Control
{
    public partial class QuestionTest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //check Session state to see what question user is up to
            //get question from db with sql
            //IF question is checkbox, radio or dropdownlist,
            //get list of options from db with sql
            //IF question is checkBoxQuestion then............
            CheckBoxQuestion checkBoxQuestion = (CheckBoxQuestion)LoadControl("~/CheckBoxQuestion.ascx");
            checkBoxQuestion.ID = "checkBoxQuestion";
            checkBoxQuestion.QuestionLabel.Text = "Select weapons you wish to buy:"; //text should be from db
            //add all of your options from the db to the checklist
            ListItem item1 = new ListItem("Harry Potters Wand", "option1ID"); //text is what you see, value is what its worth
            ListItem item2 = new ListItem("Pistol", "option2ID");
            ListItem item3 = new ListItem("Carrot", "option3ID");
            checkBoxQuestion.CheckBoxList.Items.Add(item1);
            checkBoxQuestion.CheckBoxList.Items.Add(item2);
            checkBoxQuestion.CheckBoxList.Items.Add(item3);
            //add checkbox question to web page somehow, but adding it to an existing element
            PlaceHolder1.Controls.Add(checkBoxQuestion);


        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            //IF can find checkBox control, do this
            CheckBoxQuestion checkBoxQuestion = (CheckBoxQuestion)PlaceHolder1.FindControl("checkBoxQuestion");
            if (checkBoxQuestion != null)
            {
                selectedAnswersLabel.Text = "";

                //go through all items in checklist and see which are selected
                foreach (ListItem item in checkBoxQuestion.CheckBoxList.Items)
                {
                    if (item.Selected)
                    {
                        //add answer to db against this user
                        //if selected item leads to bonus question, maybe load that up somehow

                        selectedAnswersLabel.Text += item.Text + "<br/>";
                    }
                }
            }
            //ELSE IF can find drop down
            //ELSE IF can find radio
            //ELSE IF can find textbox
        }
    }
}
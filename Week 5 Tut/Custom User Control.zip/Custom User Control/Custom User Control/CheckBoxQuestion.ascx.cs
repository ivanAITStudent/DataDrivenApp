﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Custom_User_Control
{
    public partial class CheckBoxQuestion : System.Web.UI.UserControl
    {
        //properties
        public Label QuestionLabel
        {
            get
            {
                return questionLabel;
            }
            set
            {
                questionLabel = value;
            }
        }
        public CheckBoxList CheckBoxList
        {
            get
            {
                return checkBoxList;
            }
            set
            {
                checkBoxList = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
                
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DDA2
{
    public class AppConstant
    {
        public const String DevConnectionString = "Data Source=SQL5006.myWindowsHosting.com;Initial Catalog=DB_9AB8B7_enterprise;User Id=DB_9AB8B7_enterprise_admin;Password=enterprise;";
        public const String TestConnectionString = "Data Source=SQL5018.myWindowsHosting.com;Initial Catalog=DB_9AB8B7_DDA5066;User Id=DB_9AB8B7_DDA5066_admin;Password=mFjH57x9;";
        public const String ProdConnectionString = "";
    }
}
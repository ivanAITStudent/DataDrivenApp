﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DDA2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection myConnection;
            SqlCommand myCommand;

            String myConnectionString = ConfigurationManager.ConnectionStrings["currentConnectionString"].ConnectionString;

            if (myConnectionString.Equals("dev"))
            {
                myConnectionString = AppConstant.DevConnectionString;
            }
            else if (myConnectionString.Equals("test"))
            {
                myConnectionString = AppConstant.TestConnectionString;
            }
            else
            {
                myConnectionString = AppConstant.ProdConnectionString;
            }
            
            myConnection = new SqlConnection();
            myConnection.ConnectionString = myConnectionString;

            myCommand = new SqlCommand("SELECT * FROM TabUser", myConnection);

            myConnection.Open();
            SqlDataReader myReader = myCommand.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Columns.Add("UserId", System.Type.GetType("System.String"));
            dt.Columns.Add("UserName", System.Type.GetType("System.String"));
            dt.Columns.Add("UserLevel", System.Type.GetType("System.String"));

            DataRow myRow;

            while (myReader.Read())
            {
                myRow = dt.NewRow();
                myRow["UserId"] = myReader["UID"].ToString();
                myRow["UserName"] = myReader["UserName"].ToString();
                myRow["UserLevel"] = myReader["UserLevel"].ToString();

                dt.Rows.Add(myRow);
            }

            GridView1.DataSource = dt;
            GridView1.DataBind();

            myConnection.Close();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType.Equals(DataControlRowType.DataRow))
            {
                Image img = new Image();
                //CheckBox chk = new CheckBox();
                DropDownList ddl = new DropDownList();

                if (e.Row.Cells[2].Text.Equals("1"))
                {
                    img.ImageUrl = "~/images/pawn.gif";
                }
                else if (e.Row.Cells[2].Text.Equals("2"))
                {
                    img.ImageUrl = "~/images/knight.gif";
                }
                else
                {
                    img.ImageUrl = "~/images/king.gif";
                }

                e.Row.Cells[2].Controls.Add(img);

                //chk.ID = "selectedID";
                //e.Row.Cells[0].Controls.Add(chk);

                for (int i = 1; i <= Int32.Parse(e.Row.Cells[0].Text); i++)
                {
                    ddl.Items.Add(i.ToString());
                }
                e.Row.Cells[0].Controls.Add(ddl);
            }
        }
    }
}